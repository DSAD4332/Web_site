function expandSearch() {
    const searchContainer = document.querySelector('.search-container');
    const searchInput = document.querySelector('#search-input');
  
    searchInput.style.width = '500px'; // Установите желаемую конечную ширину
    searchInput.focus(); // Установите фокус на поле ввода
  }
  